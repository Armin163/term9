import DigiData from './data.json'



function App() {

  return (
    <>
      {
            DigiData.map((book) => (
          
          <Digital name = {book.name} src = {book.src} />
          
        ) )

      }
    </>
  )

}


function Digital({ name, src }) {


  return (
    <>

      <h2> {name} </h2>
      <img src={src} />
     
    </>
  )
}
export default App 